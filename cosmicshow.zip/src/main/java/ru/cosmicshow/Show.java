package ru.cosmicshow;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Грандиозное космическое шоу из частиц (~4 минуты).
 * Акты: 0 Тишина, 1 Рождение звезды, 2 Сверхновая, 3 Чёрная дыра,
 * 4 Квазар, 5 Галактика, 6 Пульсары и туманности, 7 Конец и начало.
 */
public final class Show {

    public static final int TOTAL = 4800;
    public static final int[] ACT_START = {0, 200, 600, 900, 1500, 2400, 3200, 3800};

    // ---------- палитра ----------
    private static Color c(int r, int g, int b) { return Color.fromRGB(r, g, b); }

    private static final Color WHITE = c(255, 255, 255), ICE = c(170, 210, 255), CYAN = c(60, 230, 255),
            BLUE = c(40, 90, 255), VIOLET = c(150, 60, 255), MAGENTA = c(255, 50, 220), PINK = c(255, 120, 190),
            RED = c(255, 40, 40), ORANGE = c(255, 130, 20), GOLD = c(255, 200, 50), YELLOW = c(255, 240, 120),
            GREEN = c(80, 255, 140), BLACK = c(4, 0, 10), DEEP = c(30, 0, 50);

    private static final Color[] FIRE = {c(150, 20, 0), c(255, 70, 0), c(255, 160, 20), c(255, 225, 110), c(255, 255, 235)};
    private static final Color[] HOT = {c(235, 245, 255), c(255, 240, 170), c(255, 170, 50), c(230, 70, 20), c(130, 15, 20)};
    private static final Color[] JET = {c(255, 255, 255), c(120, 230, 255), c(60, 110, 255), c(170, 60, 255), c(255, 60, 200)};
    private static final Color[] JET2 = {c(255, 255, 255), c(255, 240, 120), c(255, 150, 30), c(255, 50, 50), c(190, 50, 255)};
    private static final Color[] GALAXY = {c(255, 235, 170), c(255, 190, 110), c(255, 130, 170), c(150, 110, 255), c(80, 190, 255)};
    private static final Color[] TAIL = {c(255, 255, 255), c(120, 240, 255), c(60, 110, 255), c(150, 60, 255)};

    // ---------- состояние ----------
    private final CosmicShowPlugin plugin;
    private final World world;
    private final double cx, cy, cz;
    private final double S;
    private final double D;
    private final double notifyRadius;
    private final boolean force;
    private final Random rnd = new Random();
    private final BossBar bar;
    private final Set<UUID> shown = new HashSet<>();
    private List<Player> viewers = new ArrayList<>();
    private BukkitTask task;
    private int tick = 0;
    private double fade = 1.0;

    private final double[][] neb = new double[6][3];
    private final Color[] nebCol = {MAGENTA, CYAN, VIOLET, ORANGE, GREEN, PINK};

    private static final class Flare { double[] a, b; double h; int born, life; }
    private static final class Burst { double x, y, z, r; int born, life, cnt; Color c1, c2; }
    private static final class Wave { double[] c, u, v; double rmax; int born, life, cnt; Color a, b; }

    private final List<Flare> flares = new ArrayList<>();
    private final List<Burst> bursts = new ArrayList<>();
    private final List<Wave> waves = new ArrayList<>();

    public Show(CosmicShowPlugin plugin, World world, double x, double y, double z,
                double scale, double density, double notifyRadius, boolean force) {
        this.plugin = plugin;
        this.world = world;
        this.cx = x;
        this.cy = y;
        this.cz = z;
        this.S = scale;
        this.D = density;
        this.notifyRadius = notifyRadius;
        this.force = force;
        this.bar = BossBar.bossBar(Component.text("Космическое шоу"), 0f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
        Random sr = new Random(1337);
        for (int i = 0; i < neb.length; i++) {
            double ang = i * Math.PI * 2 / neb.length + sr.nextDouble() * 0.6;
            double d = (32 + sr.nextDouble() * 22) * S;
            neb[i][0] = Math.cos(ang) * d;
            neb[i][1] = (sr.nextDouble() - 0.5) * 40 * S;
            neb[i][2] = Math.sin(ang) * d;
        }
    }

    // ---------- управление ----------
    public void start() {
        refreshViewers();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::step, 1L, 1L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
        for (UUID id : shown) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.hideBossBar(bar);
        }
        shown.clear();
    }

    public boolean isRunning() { return task != null; }

    public int getTick() { return tick; }

    public void jumpToAct(int act) {
        if (act < 0 || act >= ACT_START.length) return;
        tick = ACT_START[act];
        flares.clear();
        bursts.clear();
        waves.clear();
        fade = 1.0;
    }

    private void step() {
        try {
            if (tick >= TOTAL) {
                stop();
                plugin.showEnded(this);
                return;
            }
            if (tick % 20 == 0) refreshViewers();
            bar.progress(Math.min(1f, tick / (float) TOTAL));
            if (tick < ACT_START[1]) act0(tick);
            else if (tick < ACT_START[2]) act1(tick - ACT_START[1]);
            else if (tick < ACT_START[3]) act2(tick - ACT_START[2]);
            else if (tick < ACT_START[4]) act3(tick - ACT_START[3]);
            else if (tick < ACT_START[5]) act4(tick - ACT_START[4]);
            else if (tick < ACT_START[6]) act5(tick - ACT_START[5]);
            else if (tick < ACT_START[7]) act6(tick - ACT_START[6]);
            else act7(tick - ACT_START[7]);
            drawBursts();
            drawWaves();
            tick++;
        } catch (Throwable e) {
            plugin.getLogger().log(Level.SEVERE, "Ошибка в космическом шоу", e);
            stop();
            plugin.showEnded(this);
        }
    }

    private void refreshViewers() {
        List<Player> now = new ArrayList<>();
        double rr2 = notifyRadius * notifyRadius;
        for (Player p : world.getPlayers()) {
            Location l = p.getLocation();
            double dx = l.getX() - cx, dy = l.getY() - cy, dz = l.getZ() - cz;
            if (dx * dx + dy * dy + dz * dz <= rr2) now.add(p);
        }
        Set<UUID> ids = new HashSet<>();
        for (Player p : now) {
            ids.add(p.getUniqueId());
            if (shown.add(p.getUniqueId())) p.showBossBar(bar);
        }
        for (Iterator<UUID> it = shown.iterator(); it.hasNext(); ) {
            UUID id = it.next();
            if (!ids.contains(id)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.hideBossBar(bar);
                it.remove();
            }
        }
        viewers = now;
    }

    private void announce(String title, String sub, NamedTextColor col, BossBar.Color bc) {
        Component t = Component.text(title, col, TextDecoration.BOLD);
        bar.name(t);
        bar.color(bc);
        Title tt = Title.title(t, Component.text(sub, NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(700), Duration.ofMillis(3600), Duration.ofMillis(900)));
        for (Player p : viewers) p.showTitle(tt);
    }

    private void sfx(Sound s, float vol, float pitch) {
        for (Player p : viewers) p.playSound(p.getLocation(), s, SoundCategory.MASTER, vol, pitch);
    }

    // ---------- математика / утилиты ----------
    private double rr(double a, double b) { return a + rnd.nextDouble() * (b - a); }

    private int n(double v) {
        double x = v * D * fade;
        int k = (int) Math.floor(x);
        if (rnd.nextDouble() < x - k) k++;
        return k;
    }

    private double[] unit() {
        double z = rnd.nextDouble() * 2 - 1, a = rnd.nextDouble() * Math.PI * 2, s = Math.sqrt(1 - z * z);
        return new double[]{s * Math.cos(a), z, s * Math.sin(a)};
    }

    private static double ease(double x) {
        x = Math.max(0, Math.min(1, x));
        return x * x * (3 - 2 * x);
    }

    private static Color lerp(Color a, Color b, double t) {
        t = Math.max(0, Math.min(1, t));
        return Color.fromRGB((int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    private static Color grad(double t, Color... s) {
        t = Math.max(0, Math.min(1, t));
        double x = t * (s.length - 1);
        int i = (int) Math.floor(x);
        if (i >= s.length - 1) return s[s.length - 1];
        return lerp(s[i], s[i + 1], x - i);
    }

    private static Color hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        double hh = h * 6;
        int i = (int) Math.floor(hh);
        double f = hh - i;
        double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q;
        }
        return Color.fromRGB((int) (r * 255), (int) (g * 255), (int) (b * 255));
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static double[] norm(double[] a) {
        double l = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (l < 1e-9) return new double[]{0, 1, 0};
        return new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    private static double[] neg(double[] a) { return new double[]{-a[0], -a[1], -a[2]}; }

    private static double[][] basis(double[] a) {
        double[] ref = Math.abs(a[1]) < 0.9 ? new double[]{0, 1, 0} : new double[]{1, 0, 0};
        double[] u = norm(cross(a, ref));
        double[] v = cross(a, u);
        return new double[][]{u, v};
    }

    /** Поворот вокруг X на tx, затем вокруг Y на yaw. */
    private static double[] tilt(double x, double y, double z, double tx, double yaw) {
        double y1 = y * Math.cos(tx) - z * Math.sin(tx);
        double z1 = y * Math.sin(tx) + z * Math.cos(tx);
        double x2 = x * Math.cos(yaw) + z1 * Math.sin(yaw);
        double z2 = -x * Math.sin(yaw) + z1 * Math.cos(yaw);
        return new double[]{x2, y1, z2};
    }

    // ---------- примитивы частиц ----------
    private void dust(double x, double y, double z, Color col, float size) {
        world.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0, new Particle.DustOptions(col, size), force);
    }

    private void blob(double x, double y, double z, Color col, float size, int count, double spread) {
        if (count <= 0) return;
        world.spawnParticle(Particle.DUST, x, y, z, count, spread, spread, spread, 0, new Particle.DustOptions(col, size), force);
    }

    private void part(Particle p, double x, double y, double z, int count, double ox, double oy, double oz, double speed) {
        if (count <= 0) return;
        world.spawnParticle(p, x, y, z, count, ox, oy, oz, speed, null, force);
    }

    private void shoot(Particle p, double x, double y, double z, double dx, double dy, double dz, double speed) {
        world.spawnParticle(p, x, y, z, 0, dx, dy, dz, speed, null, force);
    }

    private void shell(double r, int cnt, Color a, Color b, float size) {
        for (int i = 0; i < cnt; i++) {
            double[] u = unit();
            dust(cx + u[0] * r, cy + u[1] * r, cz + u[2] * r, lerp(a, b, rnd.nextDouble()), size);
        }
    }

    private void ringAt(double r, int cnt, double tiltX, double yaw, Color a, Color b, float size) {
        for (int i = 0; i < cnt; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double[] p = tilt(r * Math.cos(ang), 0, r * Math.sin(ang), tiltX, yaw);
            dust(cx + p[0], cy + p[1], cz + p[2], lerp(a, b, rnd.nextDouble()), size);
        }
    }

    private void rainbowRing(int t, double r, int cnt, double tiltX, double yaw) {
        for (int i = 0; i < cnt; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double[] p = tilt(r * Math.cos(ang), 0, r * Math.sin(ang), tiltX, yaw);
            dust(cx + p[0], cy + p[1], cz + p[2], hsv(ang / (Math.PI * 2) + t * 0.008, 0.8, 1), 2.2f);
        }
    }

    private void bolt(double ax, double ay, double az, double bx, double by, double bz, int segs, Color col) {
        double px = ax, py = ay, pz = az;
        double len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        double jit = len / segs * 0.8;
        for (int k = 1; k <= segs; k++) {
            double f = k / (double) segs;
            double qx = ax + (bx - ax) * f, qy = ay + (by - ay) * f, qz = az + (bz - az) * f;
            if (k < segs) { qx += rr(-jit, jit); qy += rr(-jit, jit); qz += rr(-jit, jit); }
            double dx = qx - px, dy = qy - py, dz = qz - pz;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            int steps = Math.max(1, (int) (d / 1.4));
            for (int s = 0; s < steps; s++) {
                double m = s / (double) steps;
                double x = px + dx * m, y = py + dy * m, z = pz + dz * m;
                part(Particle.ELECTRIC_SPARK, x, y, z, 1, 0, 0, 0, 0);
                if (s % 2 == 0) dust(x, y, z, col, 1.6f);
            }
            px = qx; py = qy; pz = qz;
        }
    }

    // ---------- расширяющиеся сферы и кольца ----------
    private void addBurst(double x, double y, double z, double r, int life, Color c1, Color c2, int cnt) {
        if (bursts.size() > 70) return;
        Burst b = new Burst();
        b.x = x; b.y = y; b.z = z; b.r = r; b.born = tick; b.life = life; b.c1 = c1; b.c2 = c2; b.cnt = cnt;
        bursts.add(b);
    }

    private void drawBursts() {
        for (Iterator<Burst> it = bursts.iterator(); it.hasNext(); ) {
            Burst b = it.next();
            int age = tick - b.born;
            if (age > b.life) { it.remove(); continue; }
            double f = age / (double) b.life;
            double r = b.r * (1 - Math.pow(1 - f, 3));
            int k = n(b.cnt * (1 - f * 0.6));
            float size = (float) (2.4 - 1.2 * f);
            for (int j = 0; j < k; j++) {
                double[] u3 = unit();
                blob(b.x + u3[0] * r, b.y + u3[1] * r, b.z + u3[2] * r, lerp(b.c1, b.c2, f + rnd.nextDouble() * 0.25), size, 2, 0.3 * S);
            }
        }
    }

    private void addWave(double[] c, double[] u, double[] v, double rmax, int life, Color a, Color b, int cnt) {
        if (waves.size() > 40) return;
        Wave w = new Wave();
        w.c = c; w.u = u; w.v = v; w.rmax = rmax; w.born = tick; w.life = life; w.a = a; w.b = b; w.cnt = cnt;
        waves.add(w);
    }

    private void drawWaves() {
        for (Iterator<Wave> it = waves.iterator(); it.hasNext(); ) {
            Wave w = it.next();
            int age = tick - w.born;
            if (age > w.life) { it.remove(); continue; }
            double f = age / (double) w.life;
            double r = w.rmax * (1 - Math.pow(1 - f, 2.5));
            int k = n(w.cnt * (1 - 0.5 * f));
            for (int j = 0; j < k; j++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double ca = Math.cos(ang) * r, sa = Math.sin(ang) * r;
                dust(w.c[0] + w.u[0] * ca + w.v[0] * sa, w.c[1] + w.u[1] * ca + w.v[1] * sa,
                        w.c[2] + w.u[2] * ca + w.v[2] * sa, lerp(w.a, w.b, f), 2.0f);
            }
        }
    }

    // ---------- крупные составные эффекты ----------
    /** Аккреционный диск со спиральными рукавами и дифференциальным вращением. */
    private void accretion(int t, double rh, double rin, double rout, int count, double tiltX, double yaw, int arms) {
        double lg = Math.log(rout / rin);
        for (int i = 0; i < count; i++) {
            double r = rin * Math.pow(rout / rin, rnd.nextDouble());
            double x = Math.log(r / rin) / lg;
            double rho = r / rh;
            double ang;
            if (rnd.nextDouble() < 0.3) ang = rnd.nextDouble() * Math.PI * 2;
            else ang = rnd.nextInt(arms) * Math.PI * 2 / arms + 2.2 * Math.log(r / rin) - 0.35 * t / Math.pow(rho, 1.5)
                    + rnd.nextGaussian() * 0.22;
            double h = rnd.nextGaussian() * 0.04 * r;
            double[] p = tilt(r * Math.cos(ang), h, r * Math.sin(ang), tiltX, yaw);
            dust(cx + p[0], cy + p[1], cz + p[2], grad(x, HOT), (float) (1.2 + 1.4 * (1 - x)));
        }
    }

    /** Потоки вещества, спирально падающие к центру. */
    private void infall(int t, int streams, double rmax, double rmin, double tiltX, double yaw, int per, Color[] g) {
        for (int k = 0; k < streams; k++) {
            double phase = (t * 0.006 + k / (double) streams) % 1.0;
            for (int j = 0; j < per; j++) {
                double u = phase - j * 0.007;
                if (u < 0) u += 1;
                double r = rmin + (rmax - rmin) * Math.pow(1 - u, 2.0);
                double ang = k * Math.PI * 2 / streams + u * 9.0;
                double[] p = tilt(r * Math.cos(ang), rnd.nextGaussian() * 0.02 * r, r * Math.sin(ang), tiltX, yaw);
                dust(cx + p[0], cy + p[1], cz + p[2], grad(1 - u, g), 1.7f);
            }
        }
    }

    /** Релятивистская струя вдоль оси a. mode: 0/1 палитры, 2 радуга. */
    private void jet(int t, double[] a, double len, int cnt, int mode) {
        double[][] bs = basis(a);
        double[] u = bs[0], v = bs[1];
        for (int i = 0; i < cnt; i++) {
            double f = Math.pow(rnd.nextDouble(), 0.85);
            double s = len * f;
            double rad = (0.5 * S + s * 0.03) * (rnd.nextDouble() < 0.3 ? rnd.nextDouble() * 0.4 : 1.0);
            double ang = s * 0.11 - t * 0.33 + (rnd.nextBoolean() ? 0 : Math.PI);
            double ca = Math.cos(ang) * rad, sa = Math.sin(ang) * rad;
            double x = a[0] * s + u[0] * ca + v[0] * sa;
            double y = a[1] * s + u[1] * ca + v[1] * sa;
            double z = a[2] * s + u[2] * ca + v[2] * sa;
            Color col;
            if (mode == 0) col = grad(f, JET);
            else if (mode == 1) col = grad(f, JET2);
            else col = hsv(f * 0.9 + t * 0.012, 0.75, 1);
            dust(cx + x, cy + y, cz + z, col, (float) (1.4 + 1.2 * (1 - f)));
        }
    }

    // ================= АКТ 0: ТИШИНА (0..200) =================
    private void act0(int t) {
        if (t == 0) {
            announce("ТИШИНА", "Когда-то не было ничего, кроме одной искры…", NamedTextColor.WHITE, BossBar.Color.WHITE);
            sfx(Sound.BLOCK_BEACON_AMBIENT, 1f, 0.5f);
        }
        double g = t / 200.0;
        int stars = n(35);
        for (int i = 0; i < stars; i++) {
            double[] u = unit();
            double r = rr(8, 60) * S;
            part(Particle.END_ROD, cx + u[0] * r, cy + u[1] * r, cz + u[2] * r, 1, 0, 0, 0, 0);
        }
        double r = (0.4 + 2.6 * g * g) * S;
        shell(r, n(15 + 90 * g), WHITE, ICE, 2.0f);
        int sparks = n(2 + 10 * g);
        for (int i = 0; i < sparks; i++) {
            double[] u = unit();
            double d = rr(20, 45) * S;
            shoot(Particle.END_ROD, cx + u[0] * d, cy + u[1] * d, cz + u[2] * d, -u[0], -u[1], -u[2], d / 11.5);
        }
        if (t % 40 == 0) sfx(Sound.BLOCK_BEACON_AMBIENT, 0.8f, (float) (0.5 + g));
    }

    // ================= АКТ 1: РОЖДЕНИЕ ЗВЕЗДЫ (400) =================
    private void act1(int t) {
        if (t == 0) {
            announce("РОЖДЕНИЕ ЗВЕЗДЫ", "Из облака света загорается солнце…", NamedTextColor.GOLD, BossBar.Color.YELLOW);
            sfx(Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.7f);
        }
        double g = ease(t / 400.0);
        double r = (2 + 13 * g) * S * (1 + 0.03 * Math.sin(t * 0.35));
        double hot = t > 300 ? (t - 300) / 100.0 : 0;
        int k = n(130);
        for (int i = 0; i < k; i++) {
            double[] u = unit();
            Color col = grad(0.3 + 0.6 * rnd.nextDouble() + 0.1 * g, FIRE);
            col = lerp(col, ICE, hot);
            dust(cx + u[0] * r, cy + u[1] * r, cz + u[2] * r, col, 2.4f);
        }
        shell(r * 0.7, n(50), YELLOW, WHITE, 2.8f);
        int cor = n(30);
        for (int i = 0; i < cor; i++) {
            double[] u = unit();
            double rad = r * rr(1.02, 1.25);
            shoot(Particle.FLAME, cx + u[0] * rad, cy + u[1] * rad, cz + u[2] * rad, u[0], u[1], u[2], 0.04);
        }
        int jets = n(6);
        for (int i = 0; i < jets; i++) {
            double[] u = unit();
            shoot(Particle.END_ROD, cx + u[0] * r, cy + u[1] * r, cz + u[2] * r, u[0], u[1], u[2], rr(0.3, 1.0));
        }
        if (t % 12 == 0 && flares.size() < 8) {
            Flare f = new Flare();
            f.a = unit();
            double[] o = unit();
            f.b = norm(new double[]{f.a[0] + o[0] * 0.7, f.a[1] + o[1] * 0.7, f.a[2] + o[2] * 0.7});
            f.h = rr(0.3, 0.9) * r;
            f.born = t;
            f.life = (int) rr(50, 100);
            flares.add(f);
        }
        for (Iterator<Flare> it = flares.iterator(); it.hasNext(); ) {
            Flare f = it.next();
            int age = t - f.born;
            if (age > f.life || age < 0) { it.remove(); continue; }
            double fd = Math.sin(Math.PI * age / f.life);
            int m = n(26);
            for (int j = 0; j < m; j++) {
                double s = rnd.nextDouble();
                double[] d = norm(new double[]{f.a[0] + (f.b[0] - f.a[0]) * s, f.a[1] + (f.b[1] - f.a[1]) * s, f.a[2] + (f.b[2] - f.a[2]) * s});
                double rad = r + Math.sin(Math.PI * s) * f.h * fd;
                dust(cx + d[0] * rad, cy + d[1] * rad, cz + d[2] * rad, grad(0.5 + 0.5 * rnd.nextDouble(), FIRE), 2.0f);
            }
        }
        if (t % 100 == 60) {
            addBurst(cx, cy, cz, r * 2.6, 45, WHITE, ORANGE, 110);
            sfx(Sound.ENTITY_BLAZE_SHOOT, 1f, 0.5f);
        }
        if (t > 360) {
            double[] u = unit();
            part(Particle.EXPLOSION, cx + u[0] * r, cy + u[1] * r, cz + u[2] * r, n(1.5), 0.5, 0.5, 0.5, 0);
        }
        if (t == 399) sfx(Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.5f);
    }

    // ================= АКТ 2: СВЕРХНОВАЯ (300) =================
    private void act2(int t) {
        if (t == 0) {
            announce("СВЕРХНОВАЯ", "Звезда не выдерживает собственного света!", NamedTextColor.RED, BossBar.Color.RED);
            sfx(Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.5f);
            sfx(Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1f, 0.6f);
            sfx(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.6f);
            for (int i = 0; i < 12; i++)
                part(Particle.EXPLOSION_EMITTER, cx + rr(-8, 8) * S, cy + rr(-8, 8) * S, cz + rr(-8, 8) * S, 1, 0, 0, 0, 0);
            addBurst(cx, cy, cz, 75 * S, 90, WHITE, CYAN, 160);
        }
        if (t == 10) addBurst(cx, cy, cz, 60 * S, 80, ORANGE, RED, 140);
        if (t == 25) addBurst(cx, cy, cz, 90 * S, 120, MAGENTA, VIOLET, 170);
        if (t == 50) addBurst(cx, cy, cz, 110 * S, 150, GOLD, PINK, 170);
        if (t == 90) addBurst(cx, cy, cz, 120 * S, 170, CYAN, BLUE, 170);
        if (t == 5) sfx(Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 0.6f);
        if (t == 40) sfx(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1f, 0.5f);

        if (t < 40) {
            shell(Math.min(30 * S, t * 3.0 * S), n(220), WHITE, YELLOW, 3.5f);
            int m = n(60);
            for (int i = 0; i < m; i++) {
                double[] u = unit();
                shoot(Particle.END_ROD, cx, cy, cz, u[0], u[1], u[2], rr(1.0, 3.0) * S);
            }
        }
        int fw = n(25);
        for (int i = 0; i < fw; i++) {
            double[] u = unit();
            shoot(Particle.FIREWORK, cx, cy, cz, u[0], u[1], u[2], rr(0.6, 1.2) * S);
        }
        double[][] tilts = {{0.1, 0.0}, {0.55, 1.0}, {-0.9, 2.0}};
        Color[] ca = {WHITE, ORANGE, CYAN};
        Color[] cb = {MAGENTA, RED, VIOLET};
        for (int k = 0; k < 3; k++) {
            double rad = 1.1 * t * S;
            if (rad < 120 * S) {
                int m = n(70);
                for (int i = 0; i < m; i++) {
                    double ang = rnd.nextDouble() * Math.PI * 2;
                    double[] p = tilt(rad * Math.cos(ang), 0, rad * Math.sin(ang), tilts[k][0], tilts[k][1]);
                    dust(cx + p[0], cy + p[1], cz + p[2], lerp(ca[k], cb[k], rnd.nextDouble()), 2.4f);
                }
            }
        }
        if (t > 150) {
            int m = n(10);
            for (int i = 0; i < m; i++) {
                double[] u = unit();
                double d = rr(30, 70) * S;
                part(Particle.LARGE_SMOKE, cx + u[0] * d, cy + u[1] * d, cz + u[2] * d, 1, 0.5, 0.5, 0.5, 0.01);
            }
        }
        if (t % 20 == 0) {
            double[] u = unit();
            double d = rr(15, 60) * S;
            part(Particle.EXPLOSION_EMITTER, cx + u[0] * d, cy + u[1] * d, cz + u[2] * d, 1, 0, 0, 0, 0);
        }
    }

    // ================= АКТ 3: ЧЁРНАЯ ДЫРА (600) =================
    private void act3(int t) {
        if (t == 0) {
            announce("КОЛЛАПС", "Звезда умирает. Рождается чёрная дыра…", NamedTextColor.DARK_PURPLE, BossBar.Color.PURPLE);
            sfx(Sound.ENTITY_WITHER_SPAWN, 1f, 0.5f);
        }
        double rh = 5 * S;
        if (t < 150) {
            double g = ease(t / 150.0);
            double r = (42 - 36 * g) * S;
            shell(r, n(200), VIOLET, ORANGE, 2.2f);
            int m = n(30);
            for (int i = 0; i < m; i++) {
                double[] u = unit();
                double d = r * rr(1.0, 1.3);
                shoot(Particle.END_ROD, cx + u[0] * d, cy + u[1] * d, cz + u[2] * d, -u[0], -u[1], -u[2], d / 14.0);
            }
            shell(rh * g, n(80 * g), BLACK, DEEP, 3.4f);
            infall(t, 6, 40 * S, 5 * S, 0.35, t * 0.004, 10, HOT);
            if (t % 30 == 0) sfx(Sound.ENTITY_WARDEN_HEARTBEAT, 1f, (float) (0.5 + g));
            if (t == 149) {
                addBurst(cx, cy, cz, 60 * S, 40, WHITE, VIOLET, 150);
                sfx(Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.6f);
                sfx(Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 0.6f);
            }
        } else {
            int u = t - 150;
            double g = Math.min(1.0, u / 120.0);
            double tiltX = 0.35 + 0.1 * Math.sin(t * 0.01);
            double yaw = t * 0.004;
            shell(rh, n(70), BLACK, DEEP, 3.6f);
            ringAt(rh * 1.55, n(90), Math.PI / 2, t * 0.012, WHITE, GOLD, 1.3f);
            accretion(t, rh, rh * 1.8, rh * (2 + 7 * g), n(300), tiltX, yaw, 3);
            infall(t, 5, 45 * S, rh * 1.5, tiltX, yaw, 10, HOT);
            part(Particle.PORTAL, cx, cy, cz, n(40), rh, rh, rh, 1.0);
            if (u % 60 == 0) {
                double[] a = tilt(1, 0, 0, tiltX, yaw), b = tilt(0, 0, 1, tiltX, yaw);
                addWave(new double[]{cx, cy, cz}, a, b, 55 * S, 90, ICE, VIOLET, 110);
                sfx(Sound.ENTITY_WARDEN_HEARTBEAT, 1f, 0.5f);
            }
            if (u % 100 == 0) sfx(Sound.BLOCK_BEACON_AMBIENT, 1f, 0.5f);
        }
    }

    // ================= АКТ 4: КВАЗАР (900) =================
    private void act4(int t) {
        if (t == 0) {
            announce("КВАЗАР", "Чёрная дыра проснулась — и стала ярче тысячи галактик!", NamedTextColor.AQUA, BossBar.Color.BLUE);
            sfx(Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.6f);
            sfx(Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.5f);
        }
        double rh = 5 * S;
        double g = ease(Math.min(1.0, t / 150.0));
        double tiltX = 0.3, yaw = t * 0.01;
        double[] ax = tilt(0, 1, 0, tiltX, yaw);
        double[] nx = neg(ax);
        shell(rh, n(50), BLACK, DEEP, 3.4f);
        ringAt(rh * 1.55, n(70), Math.PI / 2, t * 0.012, WHITE, ICE, 1.3f);
        accretion(t, rh, rh * 1.8, rh * (5 + 7 * g), n(250), tiltX, yaw, 3);
        double len = (30 + 70 * ease(Math.min(1.0, t / 300.0))) * S * (t > 600 ? 1.25 : 1.0);
        int mode = t < 450 ? 0 : (t < 600 ? 1 : 2);
        int jc = n(85 * g);
        jet(t, ax, len, jc, mode);
        jet(t, nx, len, jc, mode);
        int bm = n(12 * g);
        for (int i = 0; i < bm; i++) {
            shoot(Particle.END_ROD, cx + ax[0] * rr(1, 4) * S, cy + ax[1] * rr(1, 4) * S, cz + ax[2] * rr(1, 4) * S, ax[0], ax[1], ax[2], 3.5 * S);
            shoot(Particle.END_ROD, cx + nx[0] * rr(1, 4) * S, cy + nx[1] * rr(1, 4) * S, cz + nx[2] * rr(1, 4) * S, nx[0], nx[1], nx[2], 3.5 * S);
        }
        if (g > 0.5) {
            for (int k = 0; k < 4; k++) {
                double s = (t * 1.6 * S + k * len / 4.0) % len;
                Color kc = mode == 2 ? hsv(s / len + t * 0.012, 0.6, 1) : lerp(WHITE, CYAN, s / len);
                blob(cx + ax[0] * s, cy + ax[1] * s, cz + ax[2] * s, kc, 3.5f, 8, 1.2 * S);
                blob(cx + nx[0] * s, cy + nx[1] * s, cz + nx[2] * s, kc, 3.5f, 8, 1.2 * S);
            }
        }
        if (g > 0.6 && t % 25 == 0) {
            double[][] bs = basis(ax);
            addWave(new double[]{cx + ax[0] * len, cy + ax[1] * len, cz + ax[2] * len}, bs[0], bs[1], 18 * S, 50, MAGENTA, PINK, 90);
            addWave(new double[]{cx + nx[0] * len, cy + nx[1] * len, cz + nx[2] * len}, bs[0], bs[1], 18 * S, 50, MAGENTA, PINK, 90);
            part(Particle.EXPLOSION, cx + ax[0] * len, cy + ax[1] * len, cz + ax[2] * len, 1, 1, 1, 1, 0);
            part(Particle.EXPLOSION, cx + nx[0] * len, cy + nx[1] * len, cz + nx[2] * len, 1, 1, 1, 1, 0);
        }
        if (t % 6 == 0 && g > 0.4) {
            double sg = rnd.nextBoolean() ? 1 : -1;
            double s1 = rr(0.1, 0.5) * len, s2 = rr(0.6, 1.0) * len;
            double[] dir = sg > 0 ? ax : nx;
            double[] o = unit();
            bolt(cx + dir[0] * s1, cy + dir[1] * s1, cz + dir[2] * s1,
                    cx + dir[0] * s2 + o[0] * 8 * S, cy + dir[1] * s2 + o[1] * 8 * S, cz + dir[2] * s2 + o[2] * 8 * S,
                    8, rnd.nextBoolean() ? CYAN : WHITE);
        }
        if (t == 300) {
            double[] a = tilt(1, 0, 0, tiltX, yaw), b = tilt(0, 0, 1, tiltX, yaw);
            addWave(new double[]{cx, cy, cz}, a, b, 80 * S, 100, WHITE, CYAN, 140);
            sfx(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.7f);
        }
        if (t == 450 || t == 600) {
            sfx(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1f, 0.6f);
            sfx(Sound.BLOCK_BEACON_POWER_SELECT, 1f, 0.7f);
            addBurst(cx, cy, cz, 50 * S, 50, WHITE, GOLD, 130);
        }
        if (t % 50 == 0) sfx(Sound.BLOCK_BEACON_AMBIENT, 1f, (float) (0.6 + t / 1500.0));
        if (t >= 840) {
            int u = t - 840;
            shell(Math.min(90 * S, u * 1.6 * S), n(150 + u), WHITE, ICE, 4.0f);
            if (u % 15 == 0) sfx(Sound.BLOCK_NOTE_BLOCK_PLING, 1f, (float) (0.5 + u / 40.0));
        }
        if (t == 899) {
            sfx(Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.6f);
            sfx(Sound.ENTITY_ENDER_DRAGON_DEATH, 0.8f, 1.2f);
            addBurst(cx, cy, cz, 90 * S, 60, WHITE, GOLD, 170);
        }
    }

    // ================= АКТ 5: ГАЛАКТИКА (800) =================
    private void galaxy(int t, double k) {
        if (k <= 0.01) return;
        double g = ease(Math.min(1.0, t / 200.0));
        double R = (10 + 72 * g) * S;
        double tiltX = 0.95, yaw = t * 0.004;
        int arms = 4;
        int cnt = n(300 * k);
        for (int i = 0; i < cnt; i++) {
            double x = Math.pow(rnd.nextDouble(), 0.8);
            double r = R * x + 1.5 * S;
            double rs = r / S;
            double ang = rnd.nextInt(arms) * Math.PI * 2 / arms + 3.0 * Math.log(1 + rs / 4.0) - t * 0.18 / (rs + 6.0)
                    + rnd.nextGaussian() * (0.42 - 0.25 * x);
            double h = rnd.nextGaussian() * 0.6 * S * (1 - 0.6 * x);
            double[] p = tilt(r * Math.cos(ang), h, r * Math.sin(ang), tiltX, yaw);
            dust(cx + p[0], cy + p[1], cz + p[2], grad(x, GALAXY), (float) (1.2 + 1.6 * (1 - x)));
        }
        int bl = n(60 * k);
        for (int i = 0; i < bl; i++) {
            double[] p = tilt(rnd.nextGaussian() * 3.0 * S, rnd.nextGaussian() * 2.0 * S, rnd.nextGaussian() * 3.0 * S, tiltX, yaw);
            dust(cx + p[0], cy + p[1], cz + p[2], lerp(GOLD, WHITE, rnd.nextDouble()), 2.4f);
        }
        blob(cx, cy, cz, WHITE, 3.5f, 6, 1.5 * S);
        int tw = n(22 * k);
        for (int i = 0; i < tw; i++) {
            double r = R * rnd.nextDouble(), ang = rnd.nextDouble() * Math.PI * 2;
            double[] p = tilt(r * Math.cos(ang), 0, r * Math.sin(ang), tiltX, yaw);
            part(Particle.END_ROD, cx + p[0], cy + p[1], cz + p[2], 1, 0, 0, 0, 0);
        }
        for (int q = 0; q < 3; q++) {
            double rr0 = (30 + 15 * q) * S * g;
            double ang = t * 0.01 * (1 + 0.3 * q) + q * 2.0;
            double[] p = tilt(rr0 * Math.cos(ang), 0, rr0 * Math.sin(ang), tiltX + 0.4 * q, yaw);
            blob(cx + p[0], cy + p[1], cz + p[2], hsv(0.1 + q * 0.3, 0.5, 1), 2.5f, n(10 * k), 2.0 * S);
        }
        if (t % 25 == 0 && k > 0.5) {
            double r = R * rr(0.2, 1.0), ang = rnd.nextDouble() * Math.PI * 2;
            double[] p = tilt(r * Math.cos(ang), 0, r * Math.sin(ang), tiltX, yaw);
            addBurst(cx + p[0], cy + p[1], cz + p[2], 6 * S, 22, WHITE, hsv(rnd.nextDouble(), 0.6, 1), 40);
        }
    }

    private void act5(int t) {
        if (t == 0) {
            announce("ГАЛАКТИКА", "Из взрыва энергии рождается целый мир звёзд.", NamedTextColor.YELLOW, BossBar.Color.YELLOW);
            sfx(Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.8f);
            sfx(Sound.ENTITY_PLAYER_LEVELUP, 1f, 0.5f);
        }
        galaxy(t, 1.0);
        if (t == 400) {
            double tiltX = 0.95, yaw = t * 0.004;
            addWave(new double[]{cx, cy, cz}, tilt(1, 0, 0, tiltX, yaw), tilt(0, 0, 1, tiltX, yaw), 95 * S, 110, GOLD, CYAN, 150);
            sfx(Sound.BLOCK_BEACON_POWER_SELECT, 1f, 0.8f);
        }
        if (t % 40 == 0) sfx(Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, (float) rr(0.6, 1.6));
    }

    // ================= АКТ 6: ПУЛЬСАРЫ И ТУМАННОСТИ (600) =================
    private void act6(int t) {
        if (t == 0) {
            announce("ПУЛЬСАРЫ И ТУМАННОСТИ", "Космос поёт светом и красками…", NamedTextColor.LIGHT_PURPLE, BossBar.Color.PINK);
            sfx(Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.2f);
        }
        if (t < 150) galaxy(800 + t, 1.0 - t / 150.0);
        double k = Math.min(1.0, t / 100.0);
        for (int i = 0; i < neb.length; i++) {
            double sway = Math.sin(t * 0.02 + i) * 2 * S;
            int nb = n(5 * k);
            for (int j = 0; j < nb; j++) {
                double x = neb[i][0] + rnd.nextGaussian() * 6 * S + sway;
                double y = neb[i][1] + rnd.nextGaussian() * 4 * S;
                double z = neb[i][2] + rnd.nextGaussian() * 6 * S - sway;
                blob(cx + x, cy + y, cz + z, lerp(nebCol[i], WHITE, rnd.nextDouble() * 0.3), 3.5f, 6, 2.2 * S);
            }
            if (rnd.nextDouble() < 0.4 * k)
                part(Particle.END_ROD, cx + neb[i][0] + rnd.nextGaussian() * 8 * S, cy + neb[i][1] + rnd.nextGaussian() * 5 * S,
                        cz + neb[i][2] + rnd.nextGaussian() * 8 * S, 1, 0, 0, 0, 0);
        }
        for (int q = 0; q < 3; q++) {
            double a = q * Math.PI * 2 / 3 + 0.5;
            double px = cx + Math.cos(a) * 35 * S, py = cy + (q - 1) * 14 * S, pz = cz + Math.sin(a) * 35 * S;
            blob(px, py, pz, WHITE, 3.5f, 5, 0.8 * S);
            double w = t * 0.17 + q * 1.7;
            double[] d = tilt(Math.cos(w), 0, Math.sin(w), 0.5 + 0.4 * q, q * 1.1);
            for (int s = 1; s <= 16; s++) {
                double dist = s * 3.2 * S;
                Color bc = lerp(WHITE, CYAN, s / 16.0);
                float sz = (float) Math.max(1.0, 2.6 - s * 0.1);
                dust(px + d[0] * dist, py + d[1] * dist, pz + d[2] * dist, bc, sz);
                dust(px - d[0] * dist, py - d[1] * dist, pz - d[2] * dist, bc, sz);
            }
            int em = n(3);
            for (int i = 0; i < em; i++) {
                shoot(Particle.END_ROD, px, py, pz, d[0], d[1], d[2], 3.0 * S);
                shoot(Particle.END_ROD, px, py, pz, -d[0], -d[1], -d[2], 3.0 * S);
            }
        }
        for (int q = 0; q < 5; q++) {
            double a = (18 + 7 * q) * S, w = 0.035 - 0.004 * q;
            double th = t * w + q * 1.9;
            double tx = 0.3 + 0.35 * q, yw = q * 1.3;
            double[] h = tilt(a * Math.cos(th), 0, a * Math.sin(th), tx, yw);
            blob(cx + h[0], cy + h[1], cz + h[2], WHITE, 3.0f, 4, 0.4 * S);
            for (int j = 1; j <= 14; j++) {
                double tj = th - j * w * 2.2;
                double[] p = tilt(a * Math.cos(tj), 0, a * Math.sin(tj), tx, yw);
                dust(cx + p[0], cy + p[1], cz + p[2], grad(j / 14.0, TAIL), (float) Math.max(0.8, 2.6 - 0.13 * j));
            }
        }
        if (t > 40) {
            double ease = ease((t - 40) / 200.0);
            rainbowRing(t, 50 * S * ease, n(180), Math.PI / 2.4, t * 0.01);
        }
        if (t % 9 == 0 && t > 60) {
            int a = rnd.nextInt(neb.length), b = rnd.nextInt(neb.length);
            if (a != b)
                bolt(cx + neb[a][0], cy + neb[a][1], cz + neb[a][2], cx + neb[b][0], cy + neb[b][1], cz + neb[b][2], 10,
                        rnd.nextBoolean() ? WHITE : CYAN);
        }
        if (t % 60 == 0) sfx(Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, (float) rr(0.5, 2.0));
        if (t % 120 == 0) sfx(Sound.BLOCK_BEACON_AMBIENT, 1f, 1.0f);
    }

    // ================= АКТ 7: КОНЕЦ… И НАЧАЛО (1000) =================
    private void act7(int t) {
        if (t == 0) {
            announce("КОНЕЦ… И НАЧАЛО", "Всё возвращается в одну точку.", NamedTextColor.GOLD, BossBar.Color.YELLOW);
            sfx(Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.6f);
        }
        if (t < 300) {
            double g = ease(t / 300.0);
            for (int k = 0; k < 6; k++) {
                double gk = Math.min(1.0, (t / 300.0) * (0.85 + 0.06 * k));
                double r = (85 * (1 - ease(gk)) + 3) * S;
                Color col = hsv(k / 6.0, 0.9, 1);
                shell(r, n(55), col, col, 2.2f);
            }
            infall(t, 10, 85 * S, 3 * S, 0.5, t * 0.02, 8, GALAXY);
            shell((1 + 5 * g) * S * (1 + 0.1 * Math.sin(t)), n(40 + 60 * g), WHITE, ICE, 3.0f);
            int per = Math.max(3, (int) (20 - 17 * g));
            if (t % per == 0) sfx(Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, (float) (0.5 + 1.5 * g));
            if (t % 25 == 0) sfx(Sound.ENTITY_WARDEN_HEARTBEAT, 1f, (float) (0.5 + g));
            if (t > 260) {
                int m = n(30);
                for (int i = 0; i < m; i++) {
                    double[] u = unit();
                    double d = rr(20, 60) * S;
                    shoot(Particle.END_ROD, cx + u[0] * d, cy + u[1] * d, cz + u[2] * d, -u[0], -u[1], -u[2], d / 12.0);
                }
            }
            return;
        }
        int u = t - 300;
        if (u == 0) {
            announce("НОВАЯ ВСЕЛЕННАЯ", "Всё начинается заново!", NamedTextColor.WHITE, BossBar.Color.WHITE);
            sfx(Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.5f);
            sfx(Sound.ENTITY_ENDER_DRAGON_DEATH, 1f, 0.8f);
            sfx(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.5f);
            sfx(Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 0.5f);
            for (int i = 0; i < 14; i++)
                part(Particle.EXPLOSION_EMITTER, cx + rr(-10, 10) * S, cy + rr(-10, 10) * S, cz + rr(-10, 10) * S, 1, 0, 0, 0, 0);
        }
        if (u < 60 && u % 6 == 0) {
            int k = u / 6;
            addBurst(cx, cy, cz, (60 + k * 8) * S, 60 + k * 10, hsv(k / 10.0, 0.7, 1), WHITE, 150);
        }
        if (u <= 50 && u % 10 == 0) {
            double[] a = tilt(1, 0, 0, rnd.nextDouble() * 3, rnd.nextDouble() * 6);
            double[] b = norm(cross(a, unit()));
            addWave(new double[]{cx, cy, cz}, a, b, 90 * S, 100, hsv(u / 50.0, 0.7, 1), WHITE, 130);
        }
        if (u < 40) shell(u * 4.0 * S, n(260), WHITE, ICE, 3.5f);
        if (u < 400 && u % 3 == 0) {
            double[] p = unit();
            double d = rr(10, 65) * S;
            double x = cx + p[0] * d, y = cy + p[1] * d, z = cz + p[2] * d;
            addBurst(x, y, z, rr(8, 16) * S, 30, hsv(rnd.nextDouble(), 0.8, 1), hsv(rnd.nextDouble(), 0.6, 1), 40);
            part(Particle.FIREWORK, x, y, z, 30, 0, 0, 0, 0.4);
            if (u % 8 == 0) sfx(Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.7f, (float) rr(0.6, 1.4));
        }
        if (u >= 100) rainbowRing(t, 55 * S, n(120), Math.PI / 2.4, t * 0.012);
        if (u >= 150 && u < 800) {
            int m = n(12);
            for (int i = 0; i < m; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * 70 * S;
                shoot(Particle.TOTEM_OF_UNDYING, cx + Math.cos(ang) * d, cy + rr(-50, 20) * S, cz + Math.sin(ang) * d, 0, 0.3, 0, 1.0);
            }
        }
        if (u >= 250) {
            int m = n(30);
            for (int i = 0; i < m; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * 70 * S;
                shoot(Particle.END_ROD, cx + Math.cos(ang) * d, cy + rr(-50, 50) * S, cz + Math.sin(ang) * d, 0, -0.05, 0, 1.0);
            }
            double rad = 7 * S;
            int hc = n(120);
            for (int i = 0; i < hc; i++) {
                double s = rnd.nextDouble() * 2 - 1;
                double ang = s * 14 + t * 0.08 + (rnd.nextBoolean() ? 0 : Math.PI);
                dust(cx + Math.cos(ang) * rad, cy + s * 45 * S, cz + Math.sin(ang) * rad, hsv(s * 0.5 + 0.5 + t * 0.01, 0.8, 1), 2.2f);
            }
            if (u >= 300) {
                for (int q = 0; q <= 12; q++) {
                    double s = q / 12.0 * 2 - 1;
                    double ang = s * 14 + t * 0.08;
                    double x1 = Math.cos(ang) * rad, z1 = Math.sin(ang) * rad;
                    for (int j = 1; j <= 4; j++) {
                        double mm = j / 5.0;
                        dust(cx + x1 * (1 - 2 * mm), cy + s * 45 * S, cz + z1 * (1 - 2 * mm), hsv(s * 0.5 + 0.5 + t * 0.01 + mm * 0.3, 0.5, 1), 1.4f);
                    }
                }
            }
            if (u % 60 == 0) {
                double hy = cy + rr(-40, 40) * S;
                addWave(new double[]{cx, hy, cz}, new double[]{1, 0, 0}, new double[]{0, 0, 1}, 60 * S, 80, hsv(rnd.nextDouble(), 0.7, 1), WHITE, 120);
            }
        }
        if (u > 800) fade = Math.max(0.05, 1 - (u - 800) / 190.0);
        if (u == 850) {
            announce("ЭТО ТОЛЬКО НАЧАЛО", "Спасибо, что смотрели!", NamedTextColor.GOLD, BossBar.Color.YELLOW);
            sfx(Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        if (u % 80 == 0 && u < 800) sfx(Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, (float) rr(0.6, 2.0));
    }
}
