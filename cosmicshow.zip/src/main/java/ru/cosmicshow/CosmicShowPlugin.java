package ru.cosmicshow;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class CosmicShowPlugin extends JavaPlugin implements TabExecutor {

    private Show current;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getCommand("cosmicshow") != null) {
            getCommand("cosmicshow").setExecutor(this);
            getCommand("cosmicshow").setTabCompleter(this);
        }
        getLogger().info("CosmicShow включён. Команда: /cosmicshow start");
    }

    @Override
    public void onDisable() {
        if (current != null) current.stop();
        current = null;
    }

    void showEnded(Show s) {
        if (current == s) current = null;
    }

    private void msg(CommandSender to, String text, NamedTextColor col) {
        to.sendMessage(Component.text(text, col));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("cosmicshow.use")) {
            msg(sender, "Нет прав.", NamedTextColor.RED);
            return true;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase();
        switch (sub) {
            case "start": {
                if (!(sender instanceof Player)) {
                    msg(sender, "Запускать шоу нужно от игрока (центр — над вами).", NamedTextColor.RED);
                    return true;
                }
                if (current != null && current.isRunning()) {
                    msg(sender, "Шоу уже идёт. Остановить: /cosmicshow stop", NamedTextColor.RED);
                    return true;
                }
                Player p = (Player) sender;
                double scale = getConfig().getDouble("scale", 1.0);
                double density = getConfig().getDouble("density", 1.0);
                try {
                    if (args.length > 1) scale = Double.parseDouble(args[1].replace(',', '.'));
                    if (args.length > 2) density = Double.parseDouble(args[2].replace(',', '.'));
                } catch (NumberFormatException e) {
                    msg(sender, "Использование: /cosmicshow start [масштаб] [плотность]", NamedTextColor.RED);
                    return true;
                }
                scale = Math.max(0.3, Math.min(3.0, scale));
                density = Math.max(0.1, Math.min(3.0, density));
                World w = p.getWorld();
                Location l = p.getLocation();
                double h = getConfig().getDouble("height", 35.0);
                current = new Show(this, w, l.getX(), l.getY() + h, l.getZ(), scale, density,
                        getConfig().getDouble("notify-radius", 400.0), getConfig().getBoolean("force", true));
                current.start();
                msg(sender, "Космическое шоу запущено! Длительность ~4 минуты. Смотрите вверх!", NamedTextColor.GOLD);
                return true;
            }
            case "stop": {
                if (current == null) {
                    msg(sender, "Шоу сейчас не идёт.", NamedTextColor.GRAY);
                } else {
                    current.stop();
                    current = null;
                    msg(sender, "Шоу остановлено.", NamedTextColor.YELLOW);
                }
                return true;
            }
            case "skip": {
                if (current == null) {
                    msg(sender, "Шоу сейчас не идёт.", NamedTextColor.GRAY);
                    return true;
                }
                try {
                    int act = Integer.parseInt(args.length > 1 ? args[1] : "-1");
                    if (act < 0 || act > 7) throw new NumberFormatException();
                    current.jumpToAct(act);
                    msg(sender, "Переход к акту " + act + ".", NamedTextColor.YELLOW);
                } catch (NumberFormatException e) {
                    msg(sender, "Использование: /cosmicshow skip <0-7>", NamedTextColor.RED);
                }
                return true;
            }
            default:
                msg(sender, "CosmicShow:", NamedTextColor.GOLD);
                msg(sender, "/cosmicshow start [масштаб] [плотность] — запустить шоу над собой", NamedTextColor.YELLOW);
                msg(sender, "/cosmicshow stop — остановить", NamedTextColor.YELLOW);
                msg(sender, "/cosmicshow skip <0-7> — перейти к акту (0 Тишина, 1 Звезда, 2 Сверхновая, 3 Чёрная дыра, 4 Квазар, 5 Галактика, 6 Пульсары, 7 Финал)", NamedTextColor.YELLOW);
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : new String[]{"start", "stop", "skip", "help"})
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("skip")) {
            for (int i = 0; i < 8; i++) out.add(String.valueOf(i));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
            out.add("1.0");
            out.add("1.5");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("start")) {
            out.add("1.0");
            out.add("0.5");
        }
        return out;
    }
}
